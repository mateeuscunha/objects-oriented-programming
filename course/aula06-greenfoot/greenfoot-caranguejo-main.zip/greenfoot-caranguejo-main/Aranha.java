import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class Aranha here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Aranha extends Actor
{
    /**
     * Act - do whatever the Aranha wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        movimentar();
        tentarComer();
    }
    private void movimentar() {
        move(2);
    }
    private void tentarComer() {
        Actor larva = getOneIntersectingObject(Larva.class);
        if (larva != null) {
            World mundo = getWorld();
            mundo.removeObject(larva);
            Greenfoot.playSound("comendo.wav");
        }
    }
}
