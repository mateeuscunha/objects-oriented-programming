import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;

/**
 * Escreva aqui uma descrição da classe MundoDoCarganguejo.
 * 
 * @author (seu nome) 
 * @version (um número de versão ou uma data)
 */
public class MundoDoCaranguejo extends World
{
    private boolean terminou;
    private int pontuacao;
    /**
     * Construtor para objetos da classe MundoDoCaranguejo.
     * 
     */
    public MundoDoCaranguejo()
    {    
        super(1000, 800, 1); 
        prepare();
        showText("Jogo do Caranguejo", 500, 20);
        terminou = false;
        pontuacao = 0;
        exibirPlacar();
    }
    
    private void exibirPlacar() {
        showText("Placar: " + pontuacao + " pontos", 800, 20);
    }
    
    public void contarPontosPorLarva() {
        pontuacao += 10;
        exibirPlacar();
    }
    
    public void act() {
        if (!terminou) {
            List<Larva> larvas = getObjects(Larva.class);
            List<Caranguejo> caranguejos = getObjects(Caranguejo.class);
            if (larvas.size() == 0) {
                showText ("You won!!!", 200, 300);
                terminou = true;
            }
            if (caranguejos.size() == 0) {
                showText ("GAME OVER", 200, 300);
                terminou = true;
            }
        }
    }
    
    /**
     * Prepara o mundo para o início do programa.
     * Ou seja: criar os objetos iniciais e adicioná-los ao mundo.
     */
    private void prepare()
    {
        Larva larva = new Larva();
        addObject(larva,40,30);
        larva.setLocation(74,35);
        larva.setLocation(102,37);
        Larva larva2 = new Larva();
        addObject(larva2,102,37);
        larva.setLocation(164,47);
        Larva larva3 = new Larva();
        addObject(larva3,164,47);
        Larva larva4 = new Larva();
        addObject(larva4,336,43);
        Larva larva5 = new Larva();
        addObject(larva5,505,53);
        Larva larva6 = new Larva();
        addObject(larva6,484,144);
        Larva larva7 = new Larva();
        addObject(larva7,194,258);
        Larva larva8 = new Larva();
        addObject(larva8,122,259);
        Larva larva9 = new Larva();
        addObject(larva9,116,132);
        Larva larva10 = new Larva();
        addObject(larva10,117,117);
        Larva larva11 = new Larva();
        addObject(larva11,340,156);
        Larva larva12 = new Larva();
        addObject(larva12,381,218);
        Larva larva13 = new Larva();
        addObject(larva13,597,127);
        Larva larva14 = new Larva();
        addObject(larva14,794,48);
        Larva larva15 = new Larva();
        addObject(larva15,947,32);
        Larva larva16 = new Larva();
        addObject(larva16,868,21);
        Larva larva17 = new Larva();
        addObject(larva17,672,44);
        larva17.setLocation(656,44);
        Larva larva18 = new Larva();
        addObject(larva18,656,44);
        larva17.setLocation(792,108);
        Larva larva19 = new Larva();
        addObject(larva19,792,108);
        Larva larva20 = new Larva();
        addObject(larva20,837,149);
        Larva larva21 = new Larva();
        addObject(larva21,885,85);
        larva21.setLocation(847,88);
        Larva larva22 = new Larva();
        addObject(larva22,847,88);
        larva21.setLocation(918,124);
        Larva larva23 = new Larva();
        addObject(larva23,918,124);
        Larva larva24 = new Larva();
        addObject(larva24,992,171);
        Larva larva25 = new Larva();
        addObject(larva25,973,85);
        larva25.setLocation(840,98);
        Larva larva26 = new Larva();
        addObject(larva26,840,98);
        Larva larva27 = new Larva();
        addObject(larva27,652,199);
        Larva larva28 = new Larva();
        addObject(larva28,600,260);
        Larva larva29 = new Larva();
        addObject(larva29,700,104);
        larva29.setLocation(665,91);
        Larva larva30 = new Larva();
        addObject(larva30,665,91);
        Larva larva31 = new Larva();
        addObject(larva31,538,89);
        Larva larva32 = new Larva();
        addObject(larva32,484,95);
        larva32.setLocation(412,113);
        Larva larva33 = new Larva();
        addObject(larva33,412,113);
        Larva larva34 = new Larva();
        addObject(larva34,373,107);
        larva34.setLocation(308,111);
        Larva larva35 = new Larva();
        addObject(larva35,308,111);
        larva34.setLocation(294,103);
        Larva larva36 = new Larva();
        addObject(larva36,294,103);
        larva35.setLocation(211,171);
        Larva larva37 = new Larva();
        addObject(larva37,211,171);
        larva36.setLocation(200,103);
        Larva larva38 = new Larva();
        addObject(larva38,200,103);
        Larva larva39 = new Larva();
        addObject(larva39,204,87);
        Larva larva40 = new Larva();
        addObject(larva40,284,204);
        Larva larva41 = new Larva();
        addObject(larva41,329,342);
        Larva larva42 = new Larva();
        addObject(larva42,107,430);
        Larva larva43 = new Larva();
        addObject(larva43,66,430);
        larva43.setLocation(171,492);
        Larva larva44 = new Larva();
        addObject(larva44,171,492);
        Larva larva45 = new Larva();
        addObject(larva45,201,377);
        Larva larva46 = new Larva();
        addObject(larva46,91,265);
        Larva larva47 = new Larva();
        addObject(larva47,101,326);
        larva45.setLocation(275,393);
        Larva larva48 = new Larva();
        addObject(larva48,275,393);
        Larva larva49 = new Larva();
        addObject(larva49,286,436);
        Larva larva50 = new Larva();
        addObject(larva50,118,482);
        Larva larva51 = new Larva();
        addObject(larva51,25,474);
        Larva larva52 = new Larva();
        addObject(larva52,133,635);
        Larva larva53 = new Larva();
        addObject(larva53,239,658);
        Larva larva54 = new Larva();
        addObject(larva54,258,693);
        Larva larva55 = new Larva();
        addObject(larva55,113,716);
        Larva larva56 = new Larva();
        addObject(larva56,95,519);
        larva56.setLocation(96,506);
        Larva larva57 = new Larva();
        addObject(larva57,96,506);
        Larva larva58 = new Larva();
        addObject(larva58,54,630);
        Larva larva59 = new Larva();
        addObject(larva59,91,689);
        Larva larva60 = new Larva();
        addObject(larva60,201,619);
        larva60.setLocation(194,534);
        Larva larva61 = new Larva();
        addObject(larva61,194,534);
        Larva larva62 = new Larva();
        addObject(larva62,238,525);
        Larva larva63 = new Larva();
        addObject(larva63,355,610);
        Larva larva64 = new Larva();
        addObject(larva64,294,682);
        Larva larva65 = new Larva();
        addObject(larva65,432,728);
        Larva larva66 = new Larva();
        addObject(larva66,822,719);
        larva66.setLocation(821,715);
        Larva larva67 = new Larva();
        addObject(larva67,821,715);
        larva66.setLocation(821,715);
        larva67.setLocation(749,627);
        Larva larva68 = new Larva();
        addObject(larva68,749,627);
        Larva larva69 = new Larva();
        addObject(larva69,622,521);
        larva69.setLocation(613,504);
        Larva larva70 = new Larva();
        addObject(larva70,613,504);
        larva69.setLocation(600,474);
        Larva larva71 = new Larva();
        addObject(larva71,600,474);
        Larva larva72 = new Larva();
        addObject(larva72,535,397);
        Larva larva73 = new Larva();
        addObject(larva73,482,340);
        Larva larva74 = new Larva();
        addObject(larva74,472,333);
        larva73.setLocation(472,333);
        larva73.setLocation(477,326);
        Larva larva75 = new Larva();
        addObject(larva75,493,282);
        larva75.setLocation(482,238);
        Larva larva76 = new Larva();
        addObject(larva76,482,238);
        larva75.setLocation(480,234);
        Larva larva77 = new Larva();
        addObject(larva77,480,234);
        larva75.setLocation(480,234);
        Larva larva78 = new Larva();
        addObject(larva78,449,288);
        Larva larva79 = new Larva();
        addObject(larva79,379,391);
        Larva larva80 = new Larva();
        addObject(larva80,356,508);
        Larva larva81 = new Larva();
        addObject(larva81,427,636);
        Larva larva82 = new Larva();
        addObject(larva82,613,708);
        Larva larva83 = new Larva();
        addObject(larva83,625,743);
        larva83.setLocation(621,643);
        Larva larva84 = new Larva();
        addObject(larva84,621,643);
        larva83.setLocation(614,620);
        Larva larva85 = new Larva();
        addObject(larva85,614,620);
        larva84.setLocation(576,571);
        Larva larva86 = new Larva();
        addObject(larva86,576,571);
        Larva larva87 = new Larva();
        addObject(larva87,417,358);
        Larva larva88 = new Larva();
        addObject(larva88,443,453);
        Larva larva89 = new Larva();
        addObject(larva89,505,490);
        larva89.setLocation(539,468);
        Larva larva90 = new Larva();
        addObject(larva90,643,416);
        Larva larva91 = new Larva();
        addObject(larva91,698,322);
        larva91.setLocation(716,275);
        Larva larva92 = new Larva();
        addObject(larva92,716,275);
        larva91.setLocation(763,206);
        Larva larva93 = new Larva();
        addObject(larva93,763,206);
        larva92.setLocation(765,203);
        Larva larva94 = new Larva();
        addObject(larva94,765,203);
        larva92.setLocation(809,307);
        Larva larva95 = new Larva();
        addObject(larva95,809,307);
        Larva larva96 = new Larva();
        addObject(larva96,937,477);
        larva96.setLocation(933,530);
        Larva larva97 = new Larva();
        addObject(larva97,933,530);
        Larva larva98 = new Larva();
        addObject(larva98,918,579);
        Larva larva99 = new Larva();
        addObject(larva99,896,798);
        larva99.setLocation(875,757);
        Larva larva100 = new Larva();
        addObject(larva100,875,757);
        Larva larva101 = new Larva();
        addObject(larva101,853,625);
        Larva larva102 = new Larva();
        addObject(larva102,823,483);
        larva102.setLocation(818,460);
        Larva larva103 = new Larva();
        addObject(larva103,818,460);
        larva102.setLocation(776,397);
        Larva larva104 = new Larva();
        addObject(larva104,776,397);
        larva103.setLocation(762,402);
        Larva larva105 = new Larva();
        addObject(larva105,762,402);
        larva103.setLocation(738,449);
        Larva larva106 = new Larva();
        addObject(larva106,738,449);
        Larva larva107 = new Larva();
        addObject(larva107,705,523);
        larva107.setLocation(742,511);
        Larva larva108 = new Larva();
        addObject(larva108,742,511);
        Larva larva109 = new Larva();
        addObject(larva109,817,518);
        larva109.setLocation(893,377);
        Larva larva110 = new Larva();
        addObject(larva110,893,377);
        Larva larva111 = new Larva();
        addObject(larva111,949,227);
        larva111.setLocation(927,280);
        Larva larva112 = new Larva();
        addObject(larva112,927,280);
        Larva larva113 = new Larva();
        addObject(larva113,845,204);
        larva113.setLocation(845,204);
        Larva larva114 = new Larva();
        addObject(larva114,845,204);
        Larva larva115 = new Larva();
        addObject(larva115,919,213);
        larva111.setLocation(914,318);
        Larva larva116 = new Larva();
        addObject(larva116,914,318);
        Larva larva117 = new Larva();
        addObject(larva117,609,338);
        Larva larva118 = new Larva();
        addObject(larva118,675,354);
        Larva larva119 = new Larva();
        addObject(larva119,212,337);
        Larva larva120 = new Larva();
        addObject(larva120,236,337);
        larva120.setLocation(212,331);
        Larva larva121 = new Larva();
        addObject(larva121,212,331);
        Larva larva122 = new Larva();
        addObject(larva122,207,396);
        larva122.setLocation(260,284);
        Larva larva123 = new Larva();
        addObject(larva123,260,284);
        Larva larva124 = new Larva();
        addObject(larva124,276,263);
        larva124.setLocation(276,263);
        larva37.setLocation(191,110);
        Caranguejo caranguejo = new Caranguejo();
        addObject(caranguejo,191,110);
        Caranguejo caranguejo2 = new Caranguejo();
        addObject(caranguejo2,803,339);
        Caranguejo caranguejo3 = new Caranguejo();
        addObject(caranguejo3,295,595);
        larva.setLocation(153,41);
        Lagosta lagosta = new Lagosta();
        addObject(lagosta,153,41);
        Lagosta lagosta2 = new Lagosta();
        addObject(lagosta2,148,360);
        Lagosta lagosta3 = new Lagosta();
        addObject(lagosta3,150,668);
        larva73.setLocation(551,313);
        larva102.setLocation(729,286);
        larva92.setLocation(839,501);
        larva22.setLocation(680,154);
        larva26.setLocation(721,149);
        larva25.setLocation(730,92);
        larva22.setLocation(865,81);
        larva75.setLocation(553,179);
        larva75.setLocation(548,237);
        larva119.setLocation(458,548);
        larva119.setLocation(364,292);
        larva122.setLocation(50,195);
        larva9.setLocation(53,114);
        larva8.setLocation(139,220);
        larva124.setLocation(296,261);
        larva120.setLocation(382,291);
        larva70.setLocation(663,563);
        larva54.setLocation(209,745);
        larva55.setLocation(45,748);
        larva69.setLocation(527,734);
        larva69.setLocation(615,490);
        larva71.setLocation(531,750);
        larva76.setLocation(492,555);
        larva103.setLocation(913,456);
        larva104.setLocation(861,426);
        larva119.setLocation(434,197);
        larva29.setLocation(558,187);
        larva60.setLocation(131,575);
        larva43.setLocation(212,428);
        larva50.setLocation(50,375);
        larva56.setLocation(53,550);
        larva56.setLocation(118,489);
        larva59.setLocation(102,720);
        larva91.setLocation(707,752);
        larva17.setLocation(968,94);
        larva21.setLocation(254,41);
        larva.setLocation(149,62);
        larva.setLocation(50,19);
    }
}
