
/**
 * Escreva uma descri��o da classe Gorila aqui.
 * 
 * @author (seu nome) 
 * @version (um n�mero da vers�o ou uma data)
 */
public class Gorila extends AnimalPeludo
{
    /**
     * Construtor para objetos da classe Gorila
     */
    public Gorila(String nome)
    {
        super(nome, "Gorila", 4, "hooo", "preto");
    }
}