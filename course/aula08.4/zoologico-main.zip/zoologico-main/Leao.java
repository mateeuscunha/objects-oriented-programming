
/**
 * Escreva uma descri��o da classe Leao aqui.
 * 
 * @author (seu nome) 
 * @version (um n�mero da vers�o ou uma data)
 */
public class Leao extends AnimalPeludo
{
    /**
     * Construtor para objetos da classe Leao
     */
    public Leao(String nome)
    {
        super(nome, "leao", 4, "rawww", "laranja");
    }
}