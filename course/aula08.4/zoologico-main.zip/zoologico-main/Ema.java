
/**
 * Escreva uma descri��o da classe Ema aqui.
 * 
 * @author (seu nome) 
 * @version (um n�mero da vers�o ou uma data)
 */
public class Ema extends AnimalVoador
{
    /**
     * Construtor para objetos da classe Ema
     */
    public Ema(String nome)
    {
        super(nome, "Ema", 2, "grumm", false);
    }
}