
/**
 * Escreva uma descri��o da classe Arara aqui.
 * 
 * @author (seu nome) 
 * @version (um n�mero da vers�o ou uma data)
 */
public class Arara extends AnimalVoador
{
    /**
     * Construtor para objetos da classe Arara
     */
    public Arara(String nome)
    {
        super(nome, "Arara", 2, "aha aha", true);
    }
}